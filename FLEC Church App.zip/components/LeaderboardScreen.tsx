import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ArrowLeft, Trophy, Flame, Star, Medal } from 'lucide-react';

interface User {
  id: string;
  name: string;
  phone: string;
  profileImage?: string;
  prayerStreak: number;
  totalPrayers: number;
  department?: string;
}

interface LeaderboardScreenProps {
  onBack: () => void;
  user: User;
}

export function LeaderboardScreen({ onBack, user }: LeaderboardScreenProps) {
  const leaderboardData = [
    {
      id: '1',
      name: 'Sarah Wanjiku',
      streak: 45,
      totalPrayers: 234,
      points: 1890,
      rank: 1,
      avatar: undefined
    },
    {
      id: '2',
      name: 'David Kamau',
      streak: 38,
      totalPrayers: 189,
      points: 1567,
      rank: 2,
      avatar: undefined
    },
    {
      id: '3',
      name: 'Grace Mutua',
      streak: 32,
      totalPrayers: 156,
      points: 1234,
      rank: 3,
      avatar: undefined
    },
    {
      id: user.id,
      name: user.name,
      streak: user.prayerStreak,
      totalPrayers: user.totalPrayers,
      points: 890,
      rank: 12,
      avatar: undefined,
      isCurrentUser: true
    },
    {
      id: '5',
      name: 'John Mwangi',
      streak: 28,
      totalPrayers: 134,
      points: 1120,
      rank: 4,
      avatar: undefined
    },
    {
      id: '6',
      name: 'Mary Kiprotich',
      streak: 25,
      totalPrayers: 123,
      points: 1045,
      rank: 5,
      avatar: undefined
    }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Medal className="w-6 h-6 text-amber-600" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-sm text-gray-500">#{rank}</span>;
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-500';
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-400';
      case 3:
        return 'bg-gradient-to-r from-amber-500 to-amber-600';
      default:
        return 'bg-blue-50';
    }
  };

  const sortedData = leaderboardData.sort((a, b) => b.points - a.points);

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" onClick={onBack} className="rounded-xl">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl">Prayer Leaderboard</h1>
          <p className="text-gray-600">See how you rank among the community</p>
        </div>
      </div>

      {/* Current User Stats */}
      <Card className="rounded-3xl shadow-sm border-blue-100 bg-gradient-to-br from-blue-50 to-blue-100">
        <CardHeader>
          <CardTitle className="text-lg">Your Ranking</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center">
                <span className="text-white">#{user.prayerStreak}</span>
              </div>
              <div>
                <h3 className="text-lg">{user.name}</h3>
                <p className="text-sm text-gray-600">890 points</p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-1 text-orange-600 mb-1">
                <Flame className="w-4 h-4" />
                <span>{user.prayerStreak} days</span>
              </div>
              <p className="text-sm text-gray-600">{user.totalPrayers} prayers</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Top 3 */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            <Trophy className="w-5 h-5 mr-2 text-yellow-500" />
            Top Performers
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {sortedData.slice(0, 3).map((person, index) => (
            <div key={person.id} className={`p-4 rounded-2xl ${getRankColor(index + 1)}`}>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-3">
                  {getRankIcon(index + 1)}
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={person.avatar} />
                    <AvatarFallback className="bg-white text-gray-700">
                      {person.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                </div>
                
                <div className="flex-1">
                  <h4 className="mb-1">{person.name}</h4>
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center space-x-1">
                      <Flame className="w-3 h-3" />
                      <span>{person.streak} days</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Star className="w-3 h-3" />
                      <span>{person.points} pts</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Full Leaderboard */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <CardTitle className="text-lg">Community Ranking</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {sortedData.map((person) => (
            <div 
              key={person.id} 
              className={`p-3 rounded-2xl ${
                person.isCurrentUser 
                  ? 'bg-blue-100 border-2 border-blue-300' 
                  : 'bg-gray-50'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 flex items-center justify-center">
                  {getRankIcon(person.rank)}
                </div>
                
                <Avatar className="w-10 h-10">
                  <AvatarImage src={person.avatar} />
                  <AvatarFallback className="bg-blue-600 text-white text-sm">
                    {person.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <h4 className="text-sm">{person.name}</h4>
                  <div className="flex items-center space-x-3 text-xs text-gray-600">
                    <span>{person.streak} day streak</span>
                    <span>{person.totalPrayers} prayers</span>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-sm">{person.points}</div>
                  <div className="text-xs text-gray-600">points</div>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Points Info */}
      <Card className="rounded-3xl shadow-sm border-blue-100 bg-gradient-to-br from-yellow-50 to-yellow-100">
        <CardHeader>
          <CardTitle className="text-lg">How Points Work</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span>Daily prayer completed</span>
            <span>+10 points</span>
          </div>
          <div className="flex justify-between">
            <span>Streak bonus (per day)</span>
            <span>+2 points</span>
          </div>
          <div className="flex justify-between">
            <span>Event attendance</span>
            <span>+5 points</span>
          </div>
          <div className="flex justify-between">
            <span>Helping with prayer requests</span>
            <span>+3 points</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}