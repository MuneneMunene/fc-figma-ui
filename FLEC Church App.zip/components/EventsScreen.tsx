import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Calendar } from './ui/calendar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Input } from './ui/input';
import { CalendarDays, Clock, MapPin, Users, Play, Search, Filter, BookOpen, Save, Eye } from 'lucide-react';
import { SavedNote } from '../App';

interface EventsScreenProps {
  onSaveNote: (note: Omit<SavedNote, 'id'>) => void;
}

export function EventsScreen({ onSaveNote }: EventsScreenProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [syncToPhone, setSyncToPhone] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [rsvpEvents, setRsvpEvents] = useState<Set<string>>(new Set());
  const [savedNoteIds, setSavedNoteIds] = useState<Set<string>>(new Set());

  const upcomingEvents = [
    {
      id: '1',
      title: 'Sunday Service',
      date: 'January 28, 2025',
      time: '9:00 AM - 11:30 AM',
      location: 'Main Sanctuary',
      attendees: 245,
      description: 'Join us for worship, praise, and the Word of God.',
      category: 'Worship'
    },
    {
      id: '2',
      title: 'Youth Fellowship',
      date: 'January 30, 2025',
      time: '7:00 PM - 9:00 PM',
      location: 'Youth Center',
      attendees: 45,
      description: 'Young adults gathering for fellowship and Bible study.',
      category: 'Fellowship'
    },
    {
      id: '3',
      title: 'Prayer Meeting',
      date: 'February 1, 2025',
      time: '6:00 AM - 7:00 AM',
      location: 'Prayer Room',
      attendees: 32,
      description: 'Early morning prayer and intercession.',
      category: 'Prayer'
    },
    {
      id: '4',
      title: 'Bible Study',
      date: 'February 3, 2025',
      time: '8:00 PM - 9:30 PM',
      location: 'Conference Room',
      attendees: 28,
      description: 'Deep dive into the book of Romans.',
      category: 'Study'
    }
  ];

  const pastSermons = [
    {
      id: '1',
      title: 'Walking in Faith',
      date: 'January 21, 2025',
      preacher: 'Pastor David Kamau',
      duration: '45 min',
      youtubeLink: 'https://youtube.com/watch?v=example1',
      views: 324
    },
    {
      id: '2',
      title: 'The Power of Prayer',
      date: 'January 14, 2025',
      preacher: 'Pastor Grace Wanjiku',
      duration: '38 min',
      youtubeLink: 'https://youtube.com/watch?v=example2',
      views: 289
    },
    {
      id: '3',
      title: 'Love Your Neighbor',
      date: 'January 7, 2025',
      preacher: 'Pastor Samuel Mutua',
      duration: '42 min',
      youtubeLink: 'https://youtube.com/watch?v=example3',
      views: 412
    },
    {
      id: '4',
      title: 'God\'s Grace',
      date: 'December 31, 2024',
      preacher: 'Pastor David Kamau',
      duration: '50 min',
      youtubeLink: 'https://youtube.com/watch?v=example4',
      views: 156
    }
  ];

  const sermonNotes = [
    {
      id: '1',
      title: 'Walking in Faith - Key Points',
      preview: 'Faith requires action. We must step out even when we cannot see the full picture. God\'s timing is perfect...',
      content: 'Faith requires action. We must step out even when we cannot see the full picture. God\'s timing is perfect, and He will provide the way as we trust Him. Key verses: Hebrews 11:1, James 2:26. Remember that faith without works is dead, but our works should flow from faith, not the other way around.',
      date: 'January 21, 2025',
      author: 'Pastor David Kamau',
      sermonTitle: 'Walking in Faith'
    },
    {
      id: '2',
      title: 'Prayer - Our Direct Line to God',
      preview: 'Prayer is not just asking for things, but building a relationship with God. It\'s about alignment with His will...',
      content: 'Prayer is not just asking for things, but building a relationship with God. It\'s about alignment with His will and finding strength in His presence. Key verses: 1 Thessalonians 5:17, Matthew 6:9-13. The Lord\'s Prayer serves as our model for how to approach God in prayer.',
      date: 'January 14, 2025',
      author: 'Pastor Grace Wanjiku',
      sermonTitle: 'The Power of Prayer'
    },
    {
      id: '3',
      title: 'Loving Others as Christ Loved Us',
      preview: 'Love is not just a feeling but a choice and action. We are called to love unconditionally, even our enemies...',
      content: 'Love is not just a feeling but a choice and action. We are called to love unconditionally, even our enemies. Key verses: John 13:34-35, 1 Corinthians 13:4-7. Love is the greatest commandment and the evidence of our faith.',
      date: 'January 7, 2025',
      author: 'Pastor Samuel Mutua',
      sermonTitle: 'Love Your Neighbor'
    },
    {
      id: '4',
      title: 'Understanding God\'s Grace',
      preview: 'Grace is God\'s unmerited favor. It\'s not something we earn but something freely given through Christ...',
      content: 'Grace is God\'s unmerited favor. It\'s not something we earn but something freely given through Christ. Key verses: Ephesians 2:8-9, Romans 3:23-24. We are saved by grace through faith, not by works, so that no one can boast.',
      date: 'December 31, 2024',
      author: 'Pastor David Kamau',
      sermonTitle: 'God\'s Grace'
    }
  ];

  const handleRSVP = (eventId: string) => {
    setRsvpEvents(prev => {
      const newSet = new Set(prev);
      if (newSet.has(eventId)) {
        newSet.delete(eventId);
      } else {
        newSet.add(eventId);
      }
      return newSet;
    });
  };

  const handleSaveNote = (note: typeof sermonNotes[0]) => {
    const savedNote: Omit<SavedNote, 'id'> = {
      title: note.title,
      preview: note.preview,
      content: note.content,
      date: new Date().toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      }),
      type: 'sermon',
      sermonTitle: note.sermonTitle,
      author: note.author
    };
    
    onSaveNote(savedNote);
    setSavedNoteIds(prev => new Set([...prev, note.id]));
  };

  const filteredSermons = pastSermons.filter(sermon =>
    sermon.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    sermon.preacher.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredNotes = sermonNotes.filter(note =>
    note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    note.sermonTitle.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Worship': return 'bg-blue-100 text-blue-700';
      case 'Fellowship': return 'bg-green-100 text-green-700';
      case 'Prayer': return 'bg-purple-100 text-purple-700';
      case 'Study': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl">Events</h1>
          <p className="text-gray-600">Stay connected with church activities</p>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-600">Sync to phone</span>
          <Switch 
            checked={syncToPhone} 
            onCheckedChange={setSyncToPhone}
          />
        </div>
      </div>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-blue-50 rounded-2xl p-1">
          <TabsTrigger value="upcoming" className="rounded-xl">Upcoming</TabsTrigger>
          <TabsTrigger value="past" className="rounded-xl">Past Events</TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-6 mt-6">
          {/* Calendar */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Event Calendar</CardTitle>
            </CardHeader>
            <CardContent>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                className="rounded-2xl"
              />
            </CardContent>
          </Card>

          {/* Upcoming Events List */}
          <div className="space-y-4">
            <h2 className="text-xl">Upcoming Events</h2>
            
            {upcomingEvents.map((event) => {
              const hasRSVP = rsvpEvents.has(event.id);
              
              return (
                <Card key={event.id} className="rounded-3xl shadow-sm border-blue-100">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge className={getCategoryColor(event.category)}>
                            {event.category}
                          </Badge>
                        </div>
                        <CardTitle className="text-lg">{event.title}</CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-sm text-gray-600">{event.description}</p>
                    
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <CalendarDays className="w-4 h-4" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <Clock className="w-4 h-4" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-gray-600">
                        <Users className="w-4 h-4" />
                        <span>{event.attendees} attending</span>
                      </div>
                    </div>
                    
                    <Button
                      onClick={() => handleRSVP(event.id)}
                      className={`w-full h-12 rounded-2xl ${
                        hasRSVP 
                          ? 'bg-green-600 hover:bg-green-700 text-white' 
                          : 'bg-blue-600 hover:bg-blue-700 text-white'
                      }`}
                    >
                      {hasRSVP ? 'Going ✓' : 'RSVP'}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="past" className="space-y-6 mt-6">
          {/* Search and Filter */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardContent className="p-4">
              <div className="flex space-x-3">
                <div className="flex-1 relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input
                    placeholder="Search sermons, notes, or preachers..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-12 rounded-xl border-gray-200"
                  />
                </div>
                <Button variant="outline" className="h-12 px-4 rounded-xl">
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Past Events Mini-Tabs */}
          <Tabs defaultValue="sermons" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-gray-50 rounded-2xl p-1">
              <TabsTrigger value="sermons" className="rounded-xl">Sermons</TabsTrigger>
              <TabsTrigger value="notes" className="rounded-xl">Notes</TabsTrigger>
            </TabsList>

            <TabsContent value="sermons" className="space-y-4 mt-6">
              <h2 className="text-xl">Past Sermons</h2>
              
              {filteredSermons.map((sermon) => (
                <Card key={sermon.id} className="rounded-3xl shadow-sm border-blue-100">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-4">
                      <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                        <Play className="w-8 h-8 text-white" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="text-lg mb-1">{sermon.title}</h3>
                        <p className="text-sm text-gray-600 mb-2">{sermon.preacher}</p>
                        
                        <div className="flex items-center space-x-4 text-xs text-gray-500 mb-3">
                          <span>{sermon.date}</span>
                          <span>{sermon.duration}</span>
                          <span>{sermon.views} views</span>
                        </div>
                        
                        <Button 
                          size="sm" 
                          className="bg-red-600 hover:bg-red-700 text-white rounded-xl"
                          onClick={() => window.open(sermon.youtubeLink, '_blank')}
                        >
                          <Play className="w-3 h-3 mr-1" />
                          Watch
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="notes" className="space-y-4 mt-6">
              <h2 className="text-xl">Sermon Notes</h2>
              
              {filteredNotes.map((note) => {
                const isSaved = savedNoteIds.has(note.id);
                
                return (
                  <Card key={note.id} className="rounded-3xl shadow-sm border-blue-100">
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-4">
                        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center flex-shrink-0">
                          <BookOpen className="w-8 h-8 text-white" />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <h3 className="text-lg mb-1">{note.title}</h3>
                          <p className="text-sm text-gray-600 mb-2">by {note.author}</p>
                          <p className="text-sm text-gray-700 mb-3 leading-relaxed">{note.preview}</p>
                          
                          <div className="flex items-center space-x-4 text-xs text-gray-500 mb-3">
                            <span>{note.date}</span>
                            <span>From: {note.sermonTitle}</span>
                          </div>
                          
                          <div className="flex space-x-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="rounded-xl"
                            >
                              <Eye className="w-3 h-3 mr-1" />
                              View Full
                            </Button>
                            <Button 
                              size="sm" 
                              onClick={() => handleSaveNote(note)}
                              disabled={isSaved}
                              className={`rounded-xl ${
                                isSaved 
                                  ? 'bg-green-600 hover:bg-green-700 text-white' 
                                  : 'bg-blue-600 hover:bg-blue-700 text-white'
                              }`}
                            >
                              <Save className="w-3 h-3 mr-1" />
                              {isSaved ? 'Saved' : 'Save Note'}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </TabsContent>
          </Tabs>
        </TabsContent>
      </Tabs>
    </div>
  );
}