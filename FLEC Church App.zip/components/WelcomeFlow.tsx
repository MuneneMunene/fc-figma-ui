import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Checkbox } from './ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Church, Heart, Star } from 'lucide-react';

interface User {
  name: string;
  phone: string;
  profileImage?: string;
  department?: string;
}

interface WelcomeFlowProps {
  onLogin: (user: User) => void;
}

export function WelcomeFlow({ onLogin }: WelcomeFlowProps) {
  const [screen, setScreen] = useState<'welcome' | 'signup' | 'login'>('welcome');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    password: '',
    rememberMe: false
  });

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSignUp = () => {
    if (formData.name && formData.phone && formData.password) {
      onLogin({
        name: formData.name,
        phone: formData.phone
      });
    }
  };

  const handleLogin = () => {
    if (formData.phone && formData.password) {
      onLogin({
        name: 'John Doe', // Mock user
        phone: formData.phone
      });
    }
  };

  if (screen === 'welcome') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex flex-col items-center justify-center p-6">
        <div className="text-center mb-12">
          <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-700 rounded-3xl flex items-center justify-center mb-6 mx-auto shadow-lg">
            <Church className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-3xl mb-3 text-gray-800">Welcome to FLEC</h1>
          <p className="text-gray-600 text-lg">Growing in faith together</p>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <Button 
            onClick={() => setScreen('signup')}
            className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-2xl shadow-lg"
          >
            Sign Up
          </Button>
          <Button 
            onClick={() => setScreen('login')}
            variant="outline"
            className="w-full h-12 border-2 border-blue-200 text-blue-700 hover:bg-blue-50 rounded-2xl"
          >
            Login
          </Button>
        </div>

        <div className="flex items-center justify-center space-x-8 mt-16 text-blue-600">
          <div className="flex flex-col items-center">
            <Heart className="w-6 h-6 mb-2" />
            <span className="text-sm">Community</span>
          </div>
          <div className="flex flex-col items-center">
            <Church className="w-6 h-6 mb-2" />
            <span className="text-sm">Worship</span>
          </div>
          <div className="flex flex-col items-center">
            <Star className="w-6 h-6 mb-2" />
            <span className="text-sm">Growth</span>
          </div>
        </div>
      </div>
    );
  }

  if (screen === 'signup') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex flex-col items-center justify-center p-6">
        <Card className="w-full max-w-sm bg-white/80 backdrop-blur-sm shadow-xl rounded-3xl border-0">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-2xl text-gray-800">Join FLEC</CardTitle>
            <p className="text-gray-600">Create your account</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-gray-700 mb-2 block">Full Name</label>
              <Input
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Enter your full name"
                className="h-12 rounded-xl border-gray-200 bg-white/50"
              />
            </div>
            <div>
              <label className="text-sm text-gray-700 mb-2 block">Phone Number</label>
              <Input
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="0700 000 000"
                className="h-12 rounded-xl border-gray-200 bg-white/50"
              />
            </div>
            <div>
              <label className="text-sm text-gray-700 mb-2 block">Password</label>
              <Input
                type="password"
                value={formData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                placeholder="Create a password"
                className="h-12 rounded-xl border-gray-200 bg-white/50"
              />
            </div>
            <Button 
              onClick={handleSignUp}
              className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl mt-6"
            >
              Sign Up
            </Button>
            <Button 
              onClick={() => setScreen('welcome')}
              variant="ghost"
              className="w-full text-blue-600 hover:bg-blue-50"
            >
              Back to Welcome
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex flex-col items-center justify-center p-6">
      <Card className="w-full max-w-sm bg-white/80 backdrop-blur-sm shadow-xl rounded-3xl border-0">
        <CardHeader className="text-center pb-4">
          <CardTitle className="text-2xl text-gray-800">Welcome Back</CardTitle>
          <p className="text-gray-600">Sign in to continue</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-gray-700 mb-2 block">Phone Number</label>
            <Input
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder="0700 000 000"
              className="h-12 rounded-xl border-gray-200 bg-white/50"
            />
          </div>
          <div>
            <label className="text-sm text-gray-700 mb-2 block">Password</label>
            <Input
              type="password"
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              placeholder="Enter your password"
              className="h-12 rounded-xl border-gray-200 bg-white/50"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Checkbox 
              id="remember"
              checked={formData.rememberMe}
              onCheckedChange={(checked) => handleInputChange('rememberMe', !!checked)}
            />
            <label htmlFor="remember" className="text-sm text-gray-600">Remember me</label>
          </div>
          <Button 
            onClick={handleLogin}
            className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-xl mt-6"
          >
            Login
          </Button>
          <Button 
            onClick={() => setScreen('welcome')}
            variant="ghost"
            className="w-full text-blue-600 hover:bg-blue-50"
          >
            Back to Welcome
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}