import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ArrowLeft, Gift, Heart, Building, Users, Smartphone, CreditCard, Banknote } from 'lucide-react';

interface GivingScreenProps {
  onBack: () => void;
}

export function GivingScreen({ onBack }: GivingScreenProps) {
  const [selectedAmount, setSelectedAmount] = useState<string>('');
  const [customAmount, setCustomAmount] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('tithe');

  const givingCategories = [
    {
      id: 'tithe',
      name: 'Tithe',
      description: 'Monthly tithe offering',
      icon: Heart,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      id: 'offering',
      name: 'General Offering',
      description: 'Support church operations',
      icon: Gift,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      id: 'building',
      name: 'Building Project',
      description: 'New sanctuary construction',
      icon: Building,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      id: 'missions',
      name: 'Missions',
      description: 'Supporting missionary work',
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    }
  ];

  const quickAmounts = ['500', '1000', '2000', '5000'];

  const recentGiving = [
    { date: 'January 21, 2025', category: 'Tithe', amount: 2000 },
    { date: 'January 14, 2025', category: 'General Offering', amount: 500 },
    { date: 'January 7, 2025', category: 'Building Project', amount: 1000 },
    { date: 'December 31, 2024', category: 'Tithe', amount: 2000 },
  ];

  const thisMonthTotal = recentGiving
    .filter(item => item.date.includes('January 2025'))
    .reduce((sum, item) => sum + item.amount, 0);

  const handleQuickAmount = (amount: string) => {
    setSelectedAmount(amount);
    setCustomAmount('');
  };

  const handleCustomAmount = (value: string) => {
    setCustomAmount(value);
    setSelectedAmount('');
  };

  const getAmount = () => {
    return customAmount || selectedAmount;
  };

  const selectedCategoryData = givingCategories.find(cat => cat.id === selectedCategory);

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" onClick={onBack} className="rounded-xl">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl">Give</h1>
          <p className="text-gray-600">Support God's work through giving</p>
        </div>
      </div>

      <Tabs defaultValue="give" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-blue-50 rounded-2xl p-1">
          <TabsTrigger value="give" className="rounded-xl">Give Now</TabsTrigger>
          <TabsTrigger value="history" className="rounded-xl">History</TabsTrigger>
        </TabsList>

        <TabsContent value="give" className="space-y-6 mt-6">
          {/* Giving Categories */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Choose Category</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {givingCategories.map((category) => {
                const Icon = category.icon;
                const isSelected = selectedCategory === category.id;
                
                return (
                  <div
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`p-4 rounded-2xl cursor-pointer transition-colors ${
                      isSelected 
                        ? `${category.bgColor} border-2 border-current ${category.color}` 
                        : 'bg-gray-50 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        isSelected ? category.bgColor : 'bg-white'
                      }`}>
                        <Icon className={`w-5 h-5 ${isSelected ? category.color : 'text-gray-600'}`} />
                      </div>
                      <div className="flex-1">
                        <h4 className={isSelected ? category.color : 'text-gray-800'}>
                          {category.name}
                        </h4>
                        <p className={`text-sm ${isSelected ? category.color : 'text-gray-600'}`}>
                          {category.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Amount Selection */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Select Amount (KSh)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Quick Amount Buttons */}
              <div className="grid grid-cols-2 gap-3">
                {quickAmounts.map((amount) => (
                  <Button
                    key={amount}
                    variant={selectedAmount === amount ? "default" : "outline"}
                    onClick={() => handleQuickAmount(amount)}
                    className="h-12 rounded-2xl"
                  >
                    KSh {amount}
                  </Button>
                ))}
              </div>
              
              {/* Custom Amount */}
              <div>
                <label className="text-sm text-gray-700 mb-2 block">Or enter custom amount</label>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={customAmount}
                  onChange={(e) => handleCustomAmount(e.target.value)}
                  className="h-12 rounded-xl border-gray-200"
                />
              </div>
            </CardContent>
          </Card>

          {/* Payment Method */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Payment Method</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-4 bg-green-50 rounded-2xl border-2 border-green-200">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-600 rounded-xl flex items-center justify-center">
                    <Smartphone className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-green-800">M-PESA</h4>
                    <p className="text-sm text-green-600">Safe and secure mobile payment</p>
                  </div>
                  <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                    Recommended
                  </Badge>
                </div>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-2xl">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-400 rounded-xl flex items-center justify-center">
                    <CreditCard className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-gray-600">Card Payment</h4>
                    <p className="text-sm text-gray-500">Coming soon</p>
                  </div>
                </div>
              </div>
              
              <div className="p-4 bg-gray-50 rounded-2xl">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gray-400 rounded-xl flex items-center justify-center">
                    <Banknote className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-gray-600">Bank Transfer</h4>
                    <p className="text-sm text-gray-500">Coming soon</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Give Button */}
          {getAmount() && selectedCategoryData && (
            <Card className="rounded-3xl shadow-sm border-blue-100 bg-gradient-to-br from-blue-50 to-blue-100">
              <CardContent className="p-6">
                <div className="text-center mb-4">
                  <h3 className="text-lg mb-2">Ready to Give</h3>
                  <div className="text-2xl text-blue-600 mb-1">
                    KSh {Number(getAmount()).toLocaleString()}
                  </div>
                  <p className="text-sm text-gray-600">to {selectedCategoryData.name}</p>
                </div>
                
                <Button 
                  className="w-full h-14 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white rounded-2xl text-lg"
                >
                  Give via M-PESA
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-6 mt-6">
          {/* Monthly Summary */}
          <Card className="rounded-3xl shadow-sm border-blue-100 bg-gradient-to-br from-green-50 to-green-100">
            <CardHeader>
              <CardTitle className="text-lg">This Month's Giving</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-3xl text-green-600 mb-2">
                  KSh {thisMonthTotal.toLocaleString()}
                </div>
                <p className="text-sm text-gray-600">Total for January 2025</p>
              </div>
            </CardContent>
          </Card>

          {/* Recent Giving History */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Recent Giving</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentGiving.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-blue-50 rounded-2xl">
                  <div>
                    <h4 className="text-sm">{item.category}</h4>
                    <p className="text-xs text-gray-600">{item.date}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-green-600">KSh {item.amount.toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Yearly Summary */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">2025 Summary</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-xl text-blue-600">4</div>
                <div className="text-sm text-gray-600">Gifts Given</div>
              </div>
              <div className="text-center">
                <div className="text-xl text-green-600">KSh 5,500</div>
                <div className="text-sm text-gray-600">Total Amount</div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}