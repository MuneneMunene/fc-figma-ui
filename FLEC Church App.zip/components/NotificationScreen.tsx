import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ArrowLeft, Bell, Calendar, Heart, Users, Gift, CheckCircle, X } from 'lucide-react';

interface NotificationScreenProps {
  onBack: () => void;
}

export function NotificationScreen({ onBack }: NotificationScreenProps) {
  const [notifications, setNotifications] = useState([
    {
      id: '1',
      type: 'prayer',
      title: 'Prayer Request Update',
      message: 'Sarah M.\'s mother surgery was successful! 12 people joined in prayer.',
      time: '2 hours ago',
      read: false,
      icon: Heart,
      color: 'text-red-500'
    },
    {
      id: '2',
      type: 'event',
      title: 'Youth Fellowship Tonight',
      message: 'Don\'t forget about tonight\'s youth fellowship at 7:00 PM in the Youth Center.',
      time: '4 hours ago',
      read: false,
      icon: Calendar,
      color: 'text-blue-500'
    },
    {
      id: '3',
      type: 'announcement',
      title: 'Building Project Update',
      message: 'Construction is now 65% complete. Thank you for your continued support and prayers.',
      time: '1 day ago',
      read: true,
      icon: Users,
      color: 'text-green-500'
    },
    {
      id: '4',
      type: 'giving',
      title: 'Monthly Giving Report',
      message: 'This month\'s total giving: KSh 125,000. Thank you for your generosity!',
      time: '2 days ago',
      read: true,
      icon: Gift,
      color: 'text-yellow-600'
    },
    {
      id: '5',
      type: 'prayer',
      title: 'New Prayer Request',
      message: 'David K. is asking for prayers regarding his job interview tomorrow.',
      time: '3 days ago',
      read: true,
      icon: Heart,
      color: 'text-red-500'
    },
    {
      id: '6',
      type: 'event',
      title: 'Sunday Service Reminder',
      message: 'Join us this Sunday at 9:00 AM for worship and the Word. Topic: "Walking in Faith"',
      time: '4 days ago',
      read: true,
      icon: Calendar,
      color: 'text-blue-500'
    },
    {
      id: '7',
      type: 'announcement',
      title: 'Easter Celebration Planning',
      message: 'We\'re planning a special Easter service and community feast. More details coming soon!',
      time: '1 week ago',
      read: true,
      icon: Users,
      color: 'text-green-500'
    }
  ]);

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true }
          : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  const deleteNotification = (notificationId: string) => {
    setNotifications(prev => 
      prev.filter(notification => notification.id !== notificationId)
    );
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="sm" onClick={onBack} className="rounded-xl">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl">Notifications</h1>
            <p className="text-gray-600">Stay updated with church activities</p>
          </div>
        </div>
        
        {unreadCount > 0 && (
          <Badge className="bg-red-100 text-red-700 hover:bg-red-100">
            {unreadCount} new
          </Badge>
        )}
      </div>

      {/* Mark All Read Button */}
      {unreadCount > 0 && (
        <Button 
          variant="outline" 
          onClick={markAllAsRead}
          className="w-full h-12 rounded-2xl"
        >
          <CheckCircle className="w-4 h-4 mr-2" />
          Mark All as Read
        </Button>
      )}

      {/* Notifications List */}
      <div className="space-y-3">
        {notifications.length === 0 ? (
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardContent className="p-8 text-center">
              <Bell className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg mb-2 text-gray-600">No notifications</h3>
              <p className="text-sm text-gray-500">You're all caught up!</p>
            </CardContent>
          </Card>
        ) : (
          notifications.map((notification) => {
            const Icon = notification.icon;
            
            return (
              <Card 
                key={notification.id} 
                className={`rounded-3xl shadow-sm border-blue-100 ${
                  !notification.read 
                    ? 'bg-blue-50 border-blue-200' 
                    : 'bg-white'
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start space-x-4">
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center ${
                      !notification.read ? 'bg-blue-100' : 'bg-gray-100'
                    }`}>
                      <Icon className={`w-5 h-5 ${notification.color}`} />
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className={`text-sm ${!notification.read ? 'font-medium' : ''}`}>
                          {notification.title}
                        </h3>
                        <div className="flex items-center space-x-2 ml-2">
                          {!notification.read && (
                            <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteNotification(notification.id)}
                            className="p-1 h-auto text-gray-400 hover:text-red-500"
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-2 leading-relaxed">
                        {notification.message}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">{notification.time}</span>
                        {!notification.read && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => markAsRead(notification.id)}
                            className="text-xs text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg p-1 h-auto"
                          >
                            Mark as read
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Notification Settings */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <CardTitle className="text-lg">Notification Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm">Prayer Requests</span>
            <Badge variant="outline" className="text-xs">Enabled</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Event Reminders</span>
            <Badge variant="outline" className="text-xs">Enabled</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Announcements</span>
            <Badge variant="outline" className="text-xs">Enabled</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Giving Updates</span>
            <Badge variant="outline" className="text-xs">Enabled</Badge>
          </div>
          <Button variant="outline" className="w-full h-10 rounded-xl mt-4">
            Manage Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}