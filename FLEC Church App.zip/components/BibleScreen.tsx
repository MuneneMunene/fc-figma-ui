import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Bookmark, Highlighter, MessageSquare, ChevronLeft, ChevronRight } from 'lucide-react';

export function BibleScreen() {
  const [selectedVersion, setSelectedVersion] = useState('KJV');
  const [selectedBook, setSelectedBook] = useState('Genesis');
  const [selectedChapter, setSelectedChapter] = useState(1);
  const [highlightedVerses, setHighlightedVerses] = useState<Set<number>>(new Set([3, 16]));
  const [bookmarkedVerses, setBookmarkedVerses] = useState<Set<number>>(new Set([1, 16]));

  const bibleVersions = [
    { value: 'KJV', label: 'King James Version' },
    { value: 'NLT', label: 'New Living Translation' },
    { value: 'NIV', label: 'New International Version' },
    { value: 'Swahili', label: 'Biblia Takatifu (Swahili)' }
  ];

  const books = [
    'Genesis', 'Exodus', 'Leviticus', 'Numbers', 'Deuteronomy',
    'Joshua', 'Judges', 'Ruth', '1 Samuel', '2 Samuel',
    'Matthew', 'Mark', 'Luke', 'John', 'Acts',
    'Romans', '1 Corinthians', '2 Corinthians', 'Galatians'
  ];

  const sampleVerses = [
    { verse: 1, text: "In the beginning God created the heaven and the earth." },
    { verse: 2, text: "And the earth was without form, and void; and darkness was upon the face of the deep. And the Spirit of God moved upon the face of the waters." },
    { verse: 3, text: "And God said, Let there be light: and there was light." },
    { verse: 4, text: "And God saw the light, that it was good: and God divided the light from the darkness." },
    { verse: 5, text: "And God called the light Day, and the darkness he called Night. And the evening and the morning were the first day." },
    { verse: 16, text: "And God made two great lights; the greater light to rule the day, and the lesser light to rule the night: he made the stars also." },
    { verse: 27, text: "So God created man in his own image, in the image of God created he him; male and female created he them." },
    { verse: 31, text: "And God saw every thing that he had made, and, behold, it was very good. And the evening and the morning were the sixth day." }
  ];

  const toggleHighlight = (verse: number) => {
    setHighlightedVerses(prev => {
      const newSet = new Set(prev);
      if (newSet.has(verse)) {
        newSet.delete(verse);
      } else {
        newSet.add(verse);
      }
      return newSet;
    });
  };

  const toggleBookmark = (verse: number) => {
    setBookmarkedVerses(prev => {
      const newSet = new Set(prev);
      if (newSet.has(verse)) {
        newSet.delete(verse);
      } else {
        newSet.add(verse);
      }
      return newSet;
    });
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl">Bible</h1>
        <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
          Daily Reading
        </Badge>
      </div>

      {/* Version Selection */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Bible Version</CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedVersion} onValueChange={setSelectedVersion}>
            <SelectTrigger className="w-full h-12 rounded-xl border-blue-200">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {bibleVersions.map((version) => (
                <SelectItem key={version.value} value={version.value}>
                  {version.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {/* Book and Chapter Navigation */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Navigation</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-gray-700 mb-2 block">Book</label>
            <Select value={selectedBook} onValueChange={setSelectedBook}>
              <SelectTrigger className="w-full h-12 rounded-xl border-blue-200">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {books.map((book) => (
                  <SelectItem key={book} value={book}>
                    {book}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <label className="text-sm text-gray-700 mb-2 block">Chapter</label>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedChapter(Math.max(1, selectedChapter - 1))}
                  className="rounded-xl"
                  disabled={selectedChapter === 1}
                >
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <span className="flex-1 text-center py-2 px-4 bg-blue-50 rounded-xl">
                  Chapter {selectedChapter}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedChapter(selectedChapter + 1)}
                  className="rounded-xl"
                >
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Bible Text */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <CardTitle className="text-lg">{selectedBook} {selectedChapter}</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            <div className="space-y-4">
              {sampleVerses.map((verseData) => (
                <div
                  key={verseData.verse}
                  className={`p-3 rounded-2xl transition-colors ${
                    highlightedVerses.has(verseData.verse) 
                      ? 'bg-yellow-100 border border-yellow-200' 
                      : 'hover:bg-blue-50'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center text-sm">
                      {verseData.verse}
                    </span>
                    <div className="flex-1">
                      <p className="text-gray-800 leading-relaxed">{verseData.text}</p>
                      <div className="flex items-center space-x-3 mt-3">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleHighlight(verseData.verse)}
                          className={`rounded-xl ${
                            highlightedVerses.has(verseData.verse) 
                              ? 'text-yellow-600 bg-yellow-50' 
                              : 'text-gray-500 hover:text-yellow-600'
                          }`}
                        >
                          <Highlighter className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleBookmark(verseData.verse)}
                          className={`rounded-xl ${
                            bookmarkedVerses.has(verseData.verse) 
                              ? 'text-blue-600 bg-blue-50' 
                              : 'text-gray-500 hover:text-blue-600'
                          }`}
                        >
                          <Bookmark className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="rounded-xl text-gray-500 hover:text-green-600"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="rounded-2xl shadow-sm border-blue-100 p-4 text-center">
          <div className="text-2xl mb-1">12</div>
          <div className="text-sm text-gray-600">Bookmarks</div>
        </Card>
        <Card className="rounded-2xl shadow-sm border-blue-100 p-4 text-center">
          <div className="text-2xl mb-1">8</div>
          <div className="text-sm text-gray-600">Highlights</div>
        </Card>
        <Card className="rounded-2xl shadow-sm border-blue-100 p-4 text-center">
          <div className="text-2xl mb-1">5</div>
          <div className="text-sm text-gray-600">Notes</div>
        </Card>
      </div>
    </div>
  );
}