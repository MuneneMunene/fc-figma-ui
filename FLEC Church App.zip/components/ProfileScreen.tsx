import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { User, Heart, Users, FileText, Settings, Moon, LogOut, Edit, ChevronRight, BookOpen } from 'lucide-react';
import { SavedNote } from '../App';

interface UserData {
  id: string;
  name: string;
  phone: string;
  profileImage?: string;
  prayerStreak: number;
  totalPrayers: number;
  department?: string;
}

interface ProfileScreenProps {
  user: UserData;
  onLogout: () => void;
  savedNotes: SavedNote[];
}

export function ProfileScreen({ user, onLogout, savedNotes }: ProfileScreenProps) {
  const [darkMode, setDarkMode] = useState(false);
  const [showDepartments, setShowDepartments] = useState(false);
  const [showNotes, setShowNotes] = useState(false);

  const departments = [
    {
      id: '1',
      name: 'Worship Team',
      leader: 'Pastor Grace Wanjiku',
      description: 'Lead congregation in worship through music and praise',
      members: 12
    },
    {
      id: '2',
      name: 'Youth Ministry',
      leader: 'David Mutua',
      description: 'Ministering to young people aged 13-25',
      members: 45
    },
    {
      id: '3',
      name: 'Children Ministry',
      leader: 'Sarah Kamau',
      description: 'Teaching and caring for children aged 3-12',
      members: 18
    },
    {
      id: '4',
      name: 'Ushering Team',
      leader: 'John Mwangi',
      description: 'Welcoming and guiding visitors and members',
      members: 24
    },
    {
      id: '5',
      name: "Women's Fellowship",
      leader: 'Mary Wanjiku',
      description: 'Empowering and supporting women in their faith journey',
      members: 38
    }
  ];

  const userStats = [
    { label: 'Prayer Streak', value: user.prayerStreak, unit: 'days', icon: Heart, color: 'text-red-500' },
    { label: 'Total Prayers', value: user.totalPrayers, unit: 'prayers', icon: Heart, color: 'text-blue-500' },
    { label: 'Events Attended', value: 23, unit: 'events', icon: Users, color: 'text-green-500' },
    { label: 'Notes Saved', value: savedNotes.length, unit: 'notes', icon: FileText, color: 'text-purple-500' }
  ];

  const getNoteIcon = (type: string) => {
    switch (type) {
      case 'sermon':
        return <BookOpen className="w-4 h-4 text-blue-600" />;
      case 'personal':
        return <FileText className="w-4 h-4 text-green-600" />;
      default:
        return <FileText className="w-4 h-4 text-gray-600" />;
    }
  };

  const getNoteTypeColor = (type: string) => {
    switch (type) {
      case 'sermon':
        return 'bg-blue-50 border-blue-200';
      case 'personal':
        return 'bg-green-50 border-green-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="p-4 space-y-6">
      {/* Profile Header */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <Avatar className="w-20 h-20">
              <AvatarImage src={user.profileImage} />
              <AvatarFallback className="bg-blue-600 text-white text-xl">
                {user.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <h2 className="text-xl mb-1">{user.name}</h2>
              <p className="text-gray-600 mb-2">{user.phone}</p>
              {user.department && (
                <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
                  {user.department}
                </Badge>
              )}
            </div>
            
            <Button variant="outline" size="sm" className="rounded-xl">
              <Edit className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        {userStats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label} className="rounded-2xl shadow-sm border-blue-100">
              <CardContent className="p-4 text-center">
                <Icon className={`w-6 h-6 ${stat.color} mx-auto mb-2`} />
                <div className="text-2xl mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Department Section */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <CardTitle className="text-lg">Ministry Involvement</CardTitle>
        </CardHeader>
        <CardContent>
          {user.department ? (
            <div className="p-4 bg-blue-50 rounded-2xl mb-4">
              <h4 className="mb-1">Currently Serving</h4>
              <p className="text-blue-600">{user.department}</p>
            </div>
          ) : (
            <div className="p-4 bg-yellow-50 rounded-2xl mb-4">
              <h4 className="mb-1">Not Currently Serving</h4>
              <p className="text-sm text-gray-600">Consider joining a ministry to serve the community</p>
            </div>
          )}
          
          <Dialog open={showDepartments} onOpenChange={setShowDepartments}>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full h-12 rounded-2xl">
                <Users className="w-4 h-4 mr-2" />
                Browse Ministries
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Available Ministries</DialogTitle>
                <DialogDescription>
                  Choose a ministry to serve and make a difference in our church community.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {departments.map((dept) => (
                  <Card key={dept.id} className="rounded-2xl shadow-sm">
                    <CardContent className="p-4">
                      <h4 className="mb-1">{dept.name}</h4>
                      <p className="text-sm text-gray-600 mb-2">{dept.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="text-xs text-gray-500">
                          <span>Leader: {dept.leader}</span>
                          <br />
                          <span>{dept.members} members</span>
                        </div>
                        <Button size="sm" className="rounded-xl">
                          Join
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* My Notes */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">My Notes ({savedNotes.length})</CardTitle>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setShowNotes(!showNotes)}
              className="rounded-xl"
            >
              <ChevronRight className={`w-4 h-4 transition-transform ${showNotes ? 'rotate-90' : ''}`} />
            </Button>
          </div>
        </CardHeader>
        {showNotes && (
          <CardContent className="space-y-3">
            {savedNotes.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <FileText className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p>No notes saved yet</p>
                <p className="text-sm">Save sermon notes from the Events screen</p>
              </div>
            ) : (
              savedNotes.map((note) => (
                <div key={note.id} className={`p-3 rounded-2xl border ${getNoteTypeColor(note.type)}`}>
                  <div className="flex items-start space-x-3">
                    {getNoteIcon(note.type)}
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="text-sm">{note.title}</h4>
                        <Badge variant="outline" className="text-xs">
                          {note.type === 'sermon' ? 'Sermon' : 'Personal'}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-600 mb-2">{note.preview}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">{note.date}</span>
                        {note.sermonTitle && (
                          <span className="text-xs text-blue-600">From: {note.sermonTitle}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
            <Button variant="outline" className="w-full h-10 rounded-xl">
              <FileText className="w-4 h-4 mr-2" />
              Add New Note
            </Button>
          </CardContent>
        )}
      </Card>

      {/* Settings */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            <Settings className="w-5 h-5 mr-2" />
            Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Moon className="w-5 h-5 text-gray-600" />
              <span>Dark Mode</span>
            </div>
            <Switch checked={darkMode} onCheckedChange={setDarkMode} />
          </div>
          
          <Separator />
          
          <Button 
            variant="ghost" 
            className="w-full justify-start h-12 rounded-xl text-left"
          >
            <Edit className="w-5 h-5 mr-3" />
            Edit Profile
          </Button>
          
          <Button 
            variant="ghost" 
            className="w-full justify-start h-12 rounded-xl text-left"
          >
            <Settings className="w-5 h-5 mr-3" />
            App Preferences
          </Button>
          
          <Separator />
          
          <Button 
            variant="ghost" 
            onClick={onLogout}
            className="w-full justify-start h-12 rounded-xl text-left text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <LogOut className="w-5 h-5 mr-3" />
            Logout
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}