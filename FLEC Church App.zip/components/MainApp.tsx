import React, { useState } from 'react';
import { Home, BookOpen, Heart, Calendar, User, Flame, Bell } from 'lucide-react';
import { Button } from './ui/button';
import { HomeScreen } from './HomeScreen';
import { BibleScreen } from './BibleScreen';
import { GuidedPrayerScreen } from './GuidedPrayerScreen';
import { EventsScreen } from './EventsScreen';
import { ProfileScreen } from './ProfileScreen';
import { LeaderboardScreen } from './LeaderboardScreen';
import { NotificationScreen } from './NotificationScreen';
import { GivingScreen } from './GivingScreen';
import { SavedNote } from '../App';

interface User {
  id: string;
  name: string;
  phone: string;
  profileImage?: string;
  prayerStreak: number;
  totalPrayers: number;
  department?: string;
}

interface MainAppProps {
  user: User;
  onLogout: () => void;
  savedNotes: SavedNote[];
  onSaveNote: (note: Omit<SavedNote, 'id'>) => void;
}

export function MainApp({ user, onLogout, savedNotes, onSaveNote }: MainAppProps) {
  const [activeTab, setActiveTab] = useState<'home' | 'bible' | 'prayer' | 'events' | 'profile'>('home');
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showGiving, setShowGiving] = useState(false);

  const tabs = [
    { id: 'home' as const, label: 'Home', icon: Home },
    { id: 'bible' as const, label: 'Bible', icon: BookOpen },
    { id: 'prayer' as const, label: 'Prayer', icon: Heart },
    { id: 'events' as const, label: 'Events', icon: Calendar },
    { id: 'profile' as const, label: 'Profile', icon: User },
  ];

  if (showLeaderboard) {
    return <LeaderboardScreen onBack={() => setShowLeaderboard(false)} user={user} />;
  }

  if (showNotifications) {
    return <NotificationScreen onBack={() => setShowNotifications(false)} />;
  }

  if (showGiving) {
    return <GivingScreen onBack={() => setShowGiving(false)} />;
  }

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomeScreen 
            user={user} 
            onShowLeaderboard={() => setShowLeaderboard(true)}
            onShowNotifications={() => setShowNotifications(true)}
            onShowGiving={() => setShowGiving(true)}
          />
        );
      case 'bible':
        return <BibleScreen />;
      case 'prayer':
        return <GuidedPrayerScreen user={user} />;
      case 'events':
        return <EventsScreen onSaveNote={onSaveNote} />;
      case 'profile':
        return <ProfileScreen user={user} onLogout={onLogout} savedNotes={savedNotes} />;
      default:
        return <HomeScreen user={user} onShowLeaderboard={() => setShowLeaderboard(true)} onShowNotifications={() => setShowNotifications(true)} onShowGiving={() => setShowGiving(true)} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white flex flex-col">
      {/* Main Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {renderScreen()}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-blue-100 px-4 py-2">
        <div className="flex justify-around items-center max-w-lg mx-auto">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <Button
                key={tab.id}
                variant="ghost"
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center space-y-1 h-auto py-2 px-3 rounded-xl ${
                  isActive 
                    ? 'text-blue-600 bg-blue-50' 
                    : 'text-gray-500 hover:text-blue-600 hover:bg-blue-50'
                }`}
              >
                <Icon className={`w-5 h-5 ${isActive ? 'text-blue-600' : ''}`} />
                <span className="text-xs">{tab.label}</span>
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}