import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Flame, Bell, Heart, Users, CheckCircle, ExternalLink, Gift } from 'lucide-react';

interface User {
  id: string;
  name: string;
  phone: string;
  profileImage?: string;
  prayerStreak: number;
  totalPrayers: number;
  department?: string;
}

interface HomeScreenProps {
  user: User;
  onShowLeaderboard: () => void;
  onShowNotifications: () => void;
  onShowGiving: () => void;
}

export function HomeScreen({ user, onShowLeaderboard, onShowNotifications, onShowGiving }: HomeScreenProps) {
  const [expandedAnnouncement, setExpandedAnnouncement] = useState<string | null>(null);
  const [prayingFor, setPrayingFor] = useState<Set<string>>(new Set());

  const todaysEvents = [
    { id: '1', title: 'Morning Prayer', time: '6:00 AM', rsvp: false },
    { id: '2', title: 'Youth Fellowship', time: '7:00 PM', rsvp: true },
    { id: '3', title: 'Bible Study', time: '8:00 PM', rsvp: false },
  ];

  const announcements = [
    {
      id: '1',
      title: 'Church Building Project Update',
      preview: 'We are pleased to announce that the new sanctuary construction is now 60% complete...',
      content: 'We are pleased to announce that the new sanctuary construction is now 60% complete. Thanks to your generous contributions and prayers, we are on track to complete the project by December 2025. The new sanctuary will accommodate 800 people and include modern audio-visual equipment for enhanced worship experience.'
    },
    {
      id: '2',
      title: 'Upcoming Easter Celebration',
      preview: 'Join us for a special Easter service and community feast on March 31st...',
      content: 'Join us for a special Easter service and community feast on March 31st. Service starts at 9:00 AM followed by a community lunch. Please bring a dish to share if possible. We will also have special activities for children including an Easter egg hunt.'
    }
  ];

  const prayerRequests = [
    {
      id: '1',
      name: 'Sarah M.',
      request: 'Please pray for my mother who is undergoing surgery this week.',
      time: '2 hours ago',
      prayingCount: 12
    },
    {
      id: '2',
      name: 'David K.',
      request: 'Prayers needed for my job interview tomorrow. Thank you!',
      time: '5 hours ago',
      prayingCount: 8
    },
    {
      id: '3',
      name: 'Grace L.',
      request: 'Thanksgiving prayer - my sister gave birth to a healthy baby boy!',
      time: '1 day ago',
      prayingCount: 24,
      answered: true
    }
  ];

  const communityGroups = [
    { id: '1', name: 'Youth Ministry', members: 45, lastActivity: '2 hours ago' },
    { id: '2', name: "Women's Fellowship", members: 38, lastActivity: '4 hours ago' },
    { id: '3', name: 'Worship Team', members: 12, lastActivity: '1 day ago' },
    { id: '4', name: 'Sunday School Teachers', members: 18, lastActivity: '2 days ago' },
  ];

  const handleRSVP = (eventId: string) => {
    // Handle RSVP logic
    console.log('RSVP for event:', eventId);
  };

  const handlePrayerToggle = (requestId: string) => {
    setPrayingFor(prev => {
      const newSet = new Set(prev);
      if (newSet.has(requestId)) {
        newSet.delete(requestId);
      } else {
        newSet.add(requestId);
      }
      return newSet;
    });
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl">Good morning, {user.name.split(' ')[0]}!</h1>
          <p className="text-gray-600">Let's grow in faith together</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={onShowLeaderboard}
            className="flex items-center space-x-1 bg-orange-50 text-orange-600 hover:bg-orange-100 rounded-xl"
          >
            <Flame className="w-4 h-4" />
            <span>{user.prayerStreak}</span>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onShowNotifications}
            className="p-2 hover:bg-blue-50 rounded-xl"
          >
            <Bell className="w-5 h-5 text-gray-600" />
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="today" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-blue-50 rounded-2xl p-1">
          <TabsTrigger value="today" className="rounded-xl">Today</TabsTrigger>
          <TabsTrigger value="community" className="rounded-xl">Community</TabsTrigger>
        </TabsList>

        <TabsContent value="today" className="space-y-6 mt-6">
          {/* Verse of the Day */}
          <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-3xl shadow-lg border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Verse of the Day</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg mb-3 italic">
                "For I know the plans I have for you," declares the Lord, "plans to prosper you and not to harm you, to give you hope and a future."
              </p>
              <p className="text-blue-200">Jeremiah 29:11</p>
            </CardContent>
          </Card>

          {/* Today's Events */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Today's Events</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {todaysEvents.map((event) => (
                <div key={event.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-2xl">
                  <div>
                    <h4>{event.title}</h4>
                    <p className="text-sm text-gray-600">{event.time}</p>
                  </div>
                  <Button
                    size="sm"
                    variant={event.rsvp ? "default" : "outline"}
                    onClick={() => handleRSVP(event.id)}
                    className="rounded-xl"
                  >
                    {event.rsvp ? 'Going' : 'RSVP'}
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Weekly Announcements */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Weekly Announcements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {announcements.map((announcement) => (
                <div key={announcement.id} className="p-4 bg-yellow-50 rounded-2xl">
                  <h4 className="mb-2">{announcement.title}</h4>
                  <p className="text-sm text-gray-600 mb-3">
                    {expandedAnnouncement === announcement.id 
                      ? announcement.content 
                      : announcement.preview
                    }
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setExpandedAnnouncement(
                      expandedAnnouncement === announcement.id ? null : announcement.id
                    )}
                    className="text-blue-600 hover:bg-blue-50 rounded-xl p-0 h-auto"
                  >
                    {expandedAnnouncement === announcement.id ? 'Show less' : 'Read more'}
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Give Button */}
          <Button
            onClick={onShowGiving}
            className="w-full h-14 bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-white rounded-2xl shadow-lg flex items-center justify-center space-x-2"
          >
            <Gift className="w-5 h-5" />
            <span>Give</span>
          </Button>
        </TabsContent>

        <TabsContent value="community" className="space-y-6 mt-6">
          {/* Prayer Requests */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Prayer Requests</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {prayerRequests.map((request) => (
                <div key={request.id} className="p-4 bg-blue-50 rounded-2xl">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <h4>{request.name}</h4>
                      {request.answered && (
                        <Badge className="bg-green-100 text-green-700 hover:bg-green-100">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Answered
                        </Badge>
                      )}
                    </div>
                    <span className="text-xs text-gray-500">{request.time}</span>
                  </div>
                  <p className="text-sm text-gray-700 mb-3">{request.request}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-gray-500">{request.prayingCount} people praying</span>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant={prayingFor.has(request.id) ? "default" : "outline"}
                        onClick={() => handlePrayerToggle(request.id)}
                        className="rounded-xl text-xs"
                      >
                        <Heart className="w-3 h-3 mr-1" />
                        {prayingFor.has(request.id) ? 'Praying' : "I'm praying too"}
                      </Button>
                      {request.answered && (
                        <Button size="sm" variant="outline" className="rounded-xl text-xs">
                          Mark answered
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Community Groups */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Community Groups</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {communityGroups.map((group) => (
                <div key={group.id} className="flex items-center justify-between p-3 bg-blue-50 rounded-2xl">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                      <Users className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4>{group.name}</h4>
                      <p className="text-sm text-gray-600">{group.members} members • {group.lastActivity}</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="rounded-xl">
                    Join
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Social Media Links */}
          <Card className="rounded-3xl shadow-sm border-blue-100">
            <CardHeader>
              <CardTitle className="text-lg">Connect with Us</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { name: 'WhatsApp Community', color: 'bg-green-500', members: '245 members' },
                { name: 'YouTube Channel', color: 'bg-red-500', members: '1.2K subscribers' },
                { name: 'Facebook Page', color: 'bg-blue-600', members: '890 followers' }
              ].map((social) => (
                <div key={social.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-2xl">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 ${social.color} rounded-xl flex items-center justify-center`}>
                      <ExternalLink className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4>{social.name}</h4>
                      <p className="text-sm text-gray-600">{social.members}</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="rounded-xl">
                    Follow
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}