import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Flame, CheckCircle, Clock, Heart, Star } from 'lucide-react';

interface User {
  id: string;
  name: string;
  phone: string;
  profileImage?: string;
  prayerStreak: number;
  totalPrayers: number;
  department?: string;
}

interface GuidedPrayerScreenProps {
  user: User;
}

export function GuidedPrayerScreen({ user }: GuidedPrayerScreenProps) {
  const [completedPrayers, setCompletedPrayers] = useState<Set<string>>(new Set(['1']));

  const dailyDevotionals = [
    {
      id: '1',
      title: 'Morning Gratitude',
      verse: 'Give thanks in all circumstances; for this is God\'s will for you in Christ Jesus.',
      reference: '1 Thessalonians 5:18',
      prayer: 'Heavenly Father, as I begin this new day, I come before You with a heart full of gratitude. Thank You for the gift of life, for the breath in my lungs, and for Your constant presence. Help me to see Your blessings throughout this day and to share Your love with others. Guide my steps and guard my heart. In Jesus\' name, Amen.',
      duration: '3 min',
      category: 'Gratitude'
    },
    {
      id: '2',
      title: 'Seeking Wisdom',
      verse: 'If any of you lacks wisdom, you should ask God, who gives generously to all without finding fault, and it will be given to you.',
      reference: 'James 1:5',
      prayer: 'Lord God, I acknowledge that I need Your wisdom in every decision I make. Grant me discernment to choose what is right and good. When I face challenges today, remind me to seek Your guidance first. Fill my mind with Your truth and my heart with Your peace. May Your wisdom shine through my words and actions. Amen.',
      duration: '4 min',
      category: 'Wisdom'
    },
    {
      id: '3',
      title: 'Peace in Trials',
      verse: 'Peace I leave with you; my peace I give you. I do not give to you as the world gives. Do not let your hearts be troubled and do not be afraid.',
      reference: 'John 14:27',
      prayer: 'Prince of Peace, in the midst of life\'s storms, I anchor my soul in You. When anxiety tries to overwhelm me, remind me of Your perfect love that casts out fear. Help me to trust in Your plan even when I cannot see the way forward. Fill me with Your supernatural peace that surpasses all understanding. Amen.',
      duration: '5 min',
      category: 'Peace'
    }
  ];

  const markAsCompleted = (prayerId: string) => {
    setCompletedPrayers(prev => new Set([...prev, prayerId]));
  };

  const streakData = {
    current: user.prayerStreak,
    goal: 30,
    longestStreak: 21,
    thisWeek: 5
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header with Streak */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl">Guided Prayer</h1>
          <p className="text-gray-600">Daily devotionals & prayer</p>
        </div>
        <div className="flex items-center space-x-2 bg-orange-50 px-4 py-2 rounded-2xl">
          <Flame className="w-5 h-5 text-orange-600" />
          <span className="text-lg text-orange-600">{streakData.current}</span>
          <span className="text-sm text-orange-600">day streak</span>
        </div>
      </div>

      {/* Streak Progress */}
      <Card className="rounded-3xl shadow-sm border-blue-100">
        <CardHeader>
          <CardTitle className="text-lg flex items-center justify-between">
            <span>Prayer Progress</span>
            <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100">
              Goal: {streakData.goal} days
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span>Current Streak: {streakData.current} days</span>
              <span>{Math.round((streakData.current / streakData.goal) * 100)}%</span>
            </div>
            <Progress value={(streakData.current / streakData.goal) * 100} className="h-2" />
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="text-center">
              <div className="text-2xl text-blue-600">{streakData.longestStreak}</div>
              <div className="text-sm text-gray-600">Longest Streak</div>
            </div>
            <div className="text-center">
              <div className="text-2xl text-green-600">{streakData.thisWeek}</div>
              <div className="text-sm text-gray-600">This Week</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Daily Devotionals */}
      <div className="space-y-4">
        <h2 className="text-xl">Today's Devotionals</h2>
        
        {dailyDevotionals.map((devotional, index) => {
          const isCompleted = completedPrayers.has(devotional.id);
          
          return (
            <Card key={devotional.id} className={`rounded-3xl shadow-sm border-blue-100 ${isCompleted ? 'bg-green-50 border-green-200' : ''}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="outline" className="text-xs">
                        {devotional.category}
                      </Badge>
                      <div className="flex items-center space-x-1 text-sm text-gray-500">
                        <Clock className="w-3 h-3" />
                        <span>{devotional.duration}</span>
                      </div>
                    </div>
                    <CardTitle className="text-lg">{devotional.title}</CardTitle>
                  </div>
                  {isCompleted && (
                    <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Bible Verse */}
                <div className="p-4 bg-blue-50 rounded-2xl">
                  <p className="text-sm italic text-gray-700 mb-2">"{devotional.verse}"</p>
                  <p className="text-sm text-blue-600">— {devotional.reference}</p>
                </div>
                
                {/* Prayer Text */}
                <div className="p-4 bg-white border border-gray-100 rounded-2xl">
                  <h4 className="mb-2 flex items-center space-x-2">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span>Guided Prayer</span>
                  </h4>
                  <p className="text-sm text-gray-700 leading-relaxed">{devotional.prayer}</p>
                </div>
                
                {/* Action Button */}
                {!isCompleted ? (
                  <Button
                    onClick={() => markAsCompleted(devotional.id)}
                    className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white rounded-2xl"
                  >
                    Mark as Done
                  </Button>
                ) : (
                  <div className="flex items-center justify-center p-3 bg-green-100 rounded-2xl">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                    <span className="text-green-700">Prayer Completed</span>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Encouragement Card */}
      <Card className="rounded-3xl shadow-sm border-yellow-200 bg-gradient-to-br from-yellow-50 to-yellow-100">
        <CardContent className="p-6 text-center">
          <Star className="w-8 h-8 text-yellow-600 mx-auto mb-3" />
          <h3 className="text-lg mb-2 text-yellow-800">Keep Going!</h3>
          <p className="text-sm text-yellow-700">
            You're doing great! Continue your prayer journey and watch your faith grow stronger each day.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}